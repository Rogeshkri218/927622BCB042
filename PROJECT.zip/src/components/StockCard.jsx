import React from "react";

export default function StockCard({ ticker, price, lastUpdatedAt }) {
  return (
    <div className="stock-card">
      <h2>{ticker}</h2>
      <p className="price">${price.toFixed(2)}</p>
      <p className="updated">
        Updated at:<br />
        {new Date(lastUpdatedAt).toLocaleString()}
      </p>
    </div>
  );
}
