export async function fetchAuthToken(credentials) {
  const response = await fetch("http://20.244.56.144/evaluation-service/auth", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(credentials)
  });
  const data = await response.json();
  return data.access_token;
}

export async function fetchStocksList(token) {
  const response = await fetch("http://20.244.56.144/evaluation-service/stocks", {
    headers: { Authorization: `Bearer ${token}` }
  });
  const data = await response.json();
  return data.stocks;
}

export async function fetchStockDetails(ticker, token) {
  const response = await fetch(`http://20.244.56.144/evaluation-service/stocks/${ticker}`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  const data = await response.json();
  return {
    ticker,
    price: data.stock.price,
    lastUpdatedAt: data.stock.lastUpdatedAt
  };
}
